import Cocoa

var str = "Hello, playground"
// My 10 list of items Array.


var myItems : [String] = ["Purse", "Shoes", "Lipgloss", " hairproducts",]
myItems.append("shoes")
myItems += ["books", "Money", "earrings" , "clothes", "hairproducts"]

print(" myItems list contains \(myItems.count) items.")

if myItems.isEmpty {
    print ("myItems list is empty.")
} else {
print(" myItem list is not empty")
}
var firstItem = myItems [2]
var secondItem = myItems [5]
var thirdItems = myItems [8]

for myItems in myItems {
    print(myItems) 
}
